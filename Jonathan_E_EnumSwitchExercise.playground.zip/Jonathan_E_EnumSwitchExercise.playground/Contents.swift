import UIKit

enum SubwaySandwich {
    case multigrain_bread
    case lettuce
    case tomatoes
    case cucumbers
    case onions
    case ham
    case mayo
    case oil
    case italian_seasoning
}
