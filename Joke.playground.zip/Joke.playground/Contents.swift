import UIKit

var one = "Why is 6 afraid of 7?"
var two = "Cause 7 ate 9"

print(one)
print(two)
