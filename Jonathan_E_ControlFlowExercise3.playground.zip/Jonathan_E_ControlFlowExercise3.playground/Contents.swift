import UIKit

var someStrs: [String] = ["I like to collect"]

someStrs.append("Juice Bottles")
someStrs.append("Pins")
someStrs += ["Mugs"]

someStrs.sort()
print(someStrs)
