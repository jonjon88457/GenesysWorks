import UIKit

var someStrs: [String] = ["I like to collect"]

someStrs.append("Bottles")
someStrs.append("Pins")
someStrs += ["Mugs"]
for item in someStrs {
    print(item)
}
