import UIKit

struct engine {
    var engineOne = ""
    var engineTwo = ""
    var engineThree = ""
    
    func allEngines() -> String {
        return "My three engine choices are " + engineOne + " " + engineTwo + " " + engineThree
        }
}

var onlyEngine = engine (engineOne: "V4", engineTwo: "V6", engineThree: "V8")

onlyEngine.allEngines()

print(onlyEngine.allEngines())
