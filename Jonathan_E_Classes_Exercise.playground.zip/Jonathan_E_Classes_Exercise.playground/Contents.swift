import UIKit

class Tesla {
    var wheels: String = "Aero"
    var color: String = "Black"
    var interior: String = "Black"
    var SelfDriving: Bool = true
    
    func carDefined(){
        print("My car is nice")
    }
}
var car = Tesla()
