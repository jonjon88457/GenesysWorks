//import UIKit
//Top Section
var input1 = 0
var input2 = 1
var input3 = 2
var input4 = 3
var input5 = 4
var input6 = 5
var input7 = 6
var input8 = 3
var result1 = 0
var result2 = 0
var result3 = 0
var result4 = 0

//Middle Section
result1 = input1 + input2

result2 = input3 - input4

result3 = input5 * input6

if(input8 != 0){
result4 = input7 / input8
} else{
 print("Cant Divide by 0, choose a different 2nd input")
}

//Bottom Section
print(result1, result2, result3, result4)
