import UIKit
//3 Minutes into seconds
let MaxTime = 180
//Starts timer at 0 and goes to 180 seconds
for Timer in 0...MaxTime{
    //Prints seconds
    print("\(Timer) seconds")

//Says Time's Up when timer is done
if Timer == MaxTime{
print("Time's Up")
 }
}
