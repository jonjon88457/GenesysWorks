import UIKit

var mult = {(Num1: Float, Num2: Float) -> Float in
    return Num1 * Num2
}
let result = mult(2.5, 3.7)
print(result)
